package com.example.sunnygym;

public class PingResponse {
    private String message;

    public String getMessage() {
        return message;
    }
}
