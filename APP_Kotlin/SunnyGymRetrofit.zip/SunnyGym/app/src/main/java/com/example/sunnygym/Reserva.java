package com.example.sunnygym;

public class Reserva {
    private int id;
    private String actividad_name;


    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getActividadName() { return actividad_name; }
    public void setActividadName(String actividad_name) { this.actividad_name = actividad_name; }
}